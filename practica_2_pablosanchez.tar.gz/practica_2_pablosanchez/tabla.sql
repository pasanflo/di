CREATE TABLE tabla (
id serial primary key,
usuario varchar(45) not null,
contrasena varchar(45) not null,
correo varchar(45) not null,
nombre varchar(45) not null,
apellido varchar(45) not null,
descripcion varchar(150) not null
)
