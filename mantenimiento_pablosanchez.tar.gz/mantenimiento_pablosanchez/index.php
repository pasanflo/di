<?php
	
	include ("configuracion.php");
	cabecera("Indice");
?>
	Bienvenido a mi página de mantenimiento de una base de datos. Selecciona una tarea.
	<p>Desarrollado por <strong>Pablo Sánchez</strong> para <strong>DI</strong></p>
<?php
	print "</div>";
	/*conexion();	*/
	pie();

?>

